$(function () {
    var imgboxs = $('.big-wrap');
    var ctrls = $('.ctrl span');
    var imgWidth = imgboxs.width();
    var num = 0;

    for (var i = 0, len = imgboxs.length; i < len; i++) {
        imgboxs.eq(i).css('backgroundImage', 'url( "img/' + (i + 1) + '.jpg" )')
    }

    function autoplay() {
        imgboxs.eq(num)
            .animate({
                left:-imgWidth
            });

        num++;

        ctrls.eq(num).addClass('active').siblings().removeClass('active');

        if(num >= imgboxs.length){
            num = 0;
        }

        imgboxs.eq(num)
            .css({
                left: imgWidth,
                zIndex:5
            })
            .animate({
                left:0
            },function () {
                imgboxs.eq(num).siblings().css('zIndex',3)
            })
    }

    function prevplay() {
        imgboxs.eq(num)
            .animate({
                left:imgWidth
            });
        num--;

        ctrls.eq(num).addClass('active').siblings().removeClass('active');

        if(num < 0){
            num = imgboxs.length - 1;
        }

        imgboxs.eq(num)
            .css({
                left: -imgWidth,
                zIndex:5
            })
            .animate({
                left:0
            },function () {
                imgboxs.eq(num).siblings().css('zIndex',3)
            })
    }


    $('#btn').on('click',function () {
        prevplay()
    });

    ctrls.on('click',function () {
        var index = $(this).index();
        if(index > num){
            imgboxs.eq(index).siblings().css({zIndex:3});
            imgboxs.eq(num).css({zIndex:5}).animate({left:-imgWidth});
            imgboxs.eq(index).css({left:imgWidth,zIndex:5}).animate({left:0});

            num = index;

        }
        if(index < num){
            imgboxs.eq(index).siblings().css({zIndex:3});
            imgboxs.eq(num).css({zIndex:5}).animate({left:imgWidth});
            imgboxs.eq(index).css({left:-imgWidth,zIndex:5}).animate({left:0});

            num = index;
        }
        ctrls.eq(num).addClass('active').siblings().removeClass('active');
    })

});